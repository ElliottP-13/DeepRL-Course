# setup.py
from setuptools import setup

setup(
    name='ds6559',
    version='0.1.0',
    packages=['ds6559'],
)